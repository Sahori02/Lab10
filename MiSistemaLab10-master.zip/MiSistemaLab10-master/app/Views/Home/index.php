<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <div class="alert alert-primary mt-3" role="alert">
        Bienvenidos al Sistema de ...
    </div>
</main>